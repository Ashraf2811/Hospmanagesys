# Frontend

## Packages Used

1. axios: To send api requests to backend server
2. react-router-dom : To specify and define react routes
3. react-toasify : To show some notifications to user
